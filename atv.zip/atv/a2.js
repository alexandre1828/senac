const perguntas = [
    {
      pergunta: "Qual é a capital da França?",
      opcoes: ["Paris", "Londres", "Berlim", "Roma"],
      correta: "Paris"
    },
    {
      pergunta: "Quanto é 5 x 5?",
      opcoes: ["10", "20", "25", "30"],
      correta: "25"
    },
    {
      pergunta: "Quem pintou a Mona Lisa?",
      opcoes: ["Michelangelo", "Leonardo da Vinci", "Van Gogh", "Picasso"],
      correta: "Leonardo da Vinci"
    }
  ];
  
  let indice = 0;
  
  function carregarPergunta() {
    const perguntaAtual = perguntas[indice];
    document.getElementById("pergunta").textContent = perguntaAtual.pergunta;
    const opcoesDiv = document.getElementById("opcoes");
    opcoesDiv.innerHTML = "";
  
    perguntaAtual.opcoes.forEach(opcao => {
      const botao = document.createElement("button");
      botao.textContent = opcao;
      botao.onclick = () => verificarResposta(opcao);
      opcoesDiv.appendChild(botao);
    });
  }
  
  function verificarResposta(respostaSelecionada) {
    const correta = perguntas[indice].correta;
    const botoes = document.querySelectorAll("#opcoes button");
  
    botoes.forEach(botao => {
      botao.disabled = true;
      if (botao.textContent === correta) {
        botao.classList.add("correta");
      }
      if (botao.textContent === respostaSelecionada && respostaSelecionada !== correta) {
        botao.classList.add("errada");
      }
    });
  
    setTimeout(() => {
      indice++;
      if (indice < perguntas.length) {
        carregarPergunta();
      } else {
        document.querySelector(".quiz-post").innerHTML = "<p>Você completou o quiz!</p>";
      }
    }, 1500);
  }
  
  // Ativa quiz apenas para as turmas permitidas
  document.getElementById("story-turma-azul").addEventListener("click", () => {
    iniciarQuiz();
  });
  
  document.getElementById("story-turma-preta").addEventListener("click", () => {
    iniciarQuiz();
  });
  
  function iniciarQuiz() {
    indice = 0;
    document.getElementById("quiz").style.display = "block";
    carregarPergunta();
  }
  