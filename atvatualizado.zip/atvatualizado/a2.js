const perguntas = [
  {
    pergunta: "Qual é a capital da França?",
    opcoes: ["Paris", "Londres", "Berlim", "Roma"],
    correta: "Paris"
  },
  {
    pergunta: "Quanto é 5 x 5?",
    opcoes: ["10", "20", "25", "30"],
    correta: "25"
  },
  {
    pergunta: "Quem pintou a Mona Lisa?",
    opcoes: ["Michelangelo", "Leonardo da Vinci", "Van Gogh", "Picasso"],
    correta: "Leonardo da Vinci"
  },
  {
    pergunta: "Qual planeta é conhecido como planeta vermelho?",
    opcoes: ["Marte", "Vênus", "Júpiter", "Saturno"],
    correta: "Marte"
  }
];

let indice = 0;
let turmaAtual = "azul";
let pontuacao = { azul: 0, preta: 0 };

function iniciarQuiz(turma) {
  turmaAtual = turma;
  indice = 0;
  pontuacao = { azul: 0, preta: 0 };
  document.getElementById("quiz").innerHTML = `
    <div class="post-header">
      <img src="icon.jpg" alt="perfil" class="post-img">
      <span class="post-user" id="turmaAtualLabel">turma.${turmaAtual}</span>
    </div>
    <div class="post-body">
      <p id="pergunta"></p>
      <div id="opcoes" class="opcoes"></div>
      <button id="btnProximo" onclick="proximaPergunta()" style="display:none;">Próxima</button>
      <div class="placar" id="placar"></div>
    </div>
  `;
  document.getElementById("quiz").style.display = "block";
  carregarPergunta();
}

function carregarPergunta() {
  const perguntaAtual = perguntas[indice];
  document.getElementById("pergunta").textContent = perguntaAtual.pergunta;
  document.getElementById("turmaAtualLabel").textContent = `turma.${turmaAtual}`;
  const opcoesDiv = document.getElementById("opcoes");
  const btnProximo = document.getElementById("btnProximo");

  opcoesDiv.innerHTML = "";
  btnProximo.style.display = "none";

  perguntaAtual.opcoes.forEach(opcao => {
    const botao = document.createElement("button");
    botao.textContent = opcao;
    botao.onclick = () => verificarResposta(botao, opcao);
    opcoesDiv.appendChild(botao);
  });

  atualizarPlacar();
}

function verificarResposta(botao, resposta) {
  const correta = perguntas[indice].correta;
  const botoes = document.querySelectorAll("#opcoes button");

  botoes.forEach(btn => {
    btn.disabled = true;
    if (btn.textContent === correta) {
      btn.classList.add("correta");
    } else {
      btn.classList.add("errada");
    }
  });

  if (resposta === correta) {
    pontuacao[turmaAtual]++;
    document.getElementById("somAcerto").play();
  } else {
    document.getElementById("somErro").play();
  }

  document.getElementById("btnProximo").style.display = "block";
}

function proximaPergunta() {
  indice++;
  turmaAtual = turmaAtual === "azul" ? "preta" : "azul";

  if (indice < perguntas.length) {
    carregarPergunta();
  } else {
    const quizDiv = document.getElementById("quiz");
    const vencedor =
      pontuacao.azul > pontuacao.preta
        ? "🎉 Turma Azul venceu!"
        : pontuacao.preta > pontuacao.azul
        ? "🎉 Turma Preta venceu!"
        : "🤝 Empate!";

    document.getElementById("somVitoria").play();

    quizDiv.innerHTML = `
      <div class="resultado-final">
        <p>Placar final:</p>
        <p>Turma Azul: ${pontuacao.azul} ponto(s)</p>
        <p>Turma Preta: ${pontuacao.preta} ponto(s)</p>
        <strong>${vencedor}</strong>
        <button class="botao-reiniciar" onclick="iniciarQuiz('azul')">🔄 Jogar Novamente</button>
      </div>
    `;
  }
}

function atualizarPlacar() {
  document.getElementById("placar").innerHTML = `
    <span class="azul">🔵 Azul: ${pontuacao.azul}</span>
    <span class="preta">⚫ Preta: ${pontuacao.preta}</span>
  `;
}
