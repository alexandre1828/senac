const perguntas = [
    {
      pergunta: "Qual é a capital da França?",
      opcoes: ["Paris", "Londres", "Berlim", "Roma"],
      correta: "Paris"
    },
    {
      pergunta: "Quanto é 5 x 5?",
      opcoes: ["10", "20", "25", "30"],
      correta: "25"
    },
    {
      pergunta: "Quem pintou a Mona Lisa?",
      opcoes: ["Michelangelo", "Leonardo da Vinci", "Van Gogh", "Picasso"],
      correta: "Leonardo da Vinci"
    }
  ];
  
  let indice = 0;
  
  function carregarPergunta() {
    const perguntaAtual = perguntas[indice];
    document.getElementById("pergunta").textContent = perguntaAtual.pergunta;
    const opcoesDiv = document.getElementById("opcoes");
    opcoesDiv.innerHTML = "";
    perguntaAtual.opcoes.forEach(opcao => {
      const botao = document.createElement("button");
      botao.textContent = opcao;
      botao.onclick = () => verificarResposta(opcao);
      opcoesDiv.appendChild(botao);
    });
  }
  
  function verificarResposta(resposta) {
    const correta = perguntas[indice].correta;
    if (resposta === correta) {
      alert("Correta!");
    } else {
      alert(`Errado! A resposta correta era: ${correta}`);
    }
    indice++;
    if (indice < perguntas.length) {
      carregarPergunta();
    } else {
      document.querySelector(".quiz-post").innerHTML = "<p>Você completou o quiz!</p>";
    }
  }
  
  document.getElementById("story-turma").addEventListener("click", () => {
    document.getElementById("quiz").style.display = "block";
    carregarPergunta();
  });
  