const perguntas = [
  {
    pergunta: "Você vê um novo aplicativo bombando... Você entra ou prefere ficar de fora?",
    opcoes: [
      { texto: "Entrar", pontos: 10 },
      { texto: "Ficar de fora", pontos: 10 }
    ]
  },
  {
    pergunta: "Você vê uma postagem polêmica... Se posiciona ou discorda em silêncio?",
    opcoes: [
      { texto: "Se posicionar", pontos: 10 },
      { texto: "Ficar em silêncio", pontos: 10 }
    ]
  },
  {
    pergunta: "Seu perfil parece bagunçado... Recomeça ou permanece e reorganiza?",
    opcoes: [
      { texto: "Permanecer", pontos: 20 },
      { texto: "Recomeçar", pontos: 10 }
    ]
  },
  {
    pergunta: "Você gosta de alguém, mas nunca interage. Você cria coragem ou continua quieto(a)?",
    opcoes: [
      { texto: "Interagir", pontos: 10 },
      { texto: "Ficar em silêncio", pontos: 20 }
    ]
  },
  {
    pergunta: "Você está estudando e chega uma notificação. Você olha ou continua estudando?",
    opcoes: [
      { texto: "Continuar estudando", pontos: 20 },
      { texto: "Visualizar", pontos: 10 }
    ]
  },
  {
    pergunta: "Você tirou uma foto boa, mas hesita em postar. Você posta mesmo assim ou desiste?",
    opcoes: [
      { texto: "Postar mesmo assim", pontos: 20 },
      { texto: "Guardar a foto", pontos: 10 }
    ]
  },
  {
    pergunta: "Está num jantar incrível. Você guarda o celular ou tira várias fotos?",
    opcoes: [
      { texto: "Viver o momento", pontos: 20 },
      { texto: "Registrar tudo", pontos: 10 }
    ]
  }
];

let indice = 0;
let equipeAtual = "A";
let pontuacao = { A: 0, B: 0 };

function iniciarQuiz(equipe) {
  equipeAtual = equipe;
  indice = 0;
  pontuacao = { A: 0, B: 0 };
  document.getElementById("quiz").innerHTML = `
    <div class="post-header">
      <img src="imagens/icon.jpg" alt="perfil" class="post-img">
      <span class="post-user" id="equipeAtualLabel">Equipe ${equipeAtual}</span>
    </div>
    <div class="post-body">
      <p id="pergunta"></p>
      <div id="opcoes" class="opcoes"></div>
      <button id="btnProximo" onclick="proximaPergunta()">Próxima</button>
      <div class="placar" id="placar"></div>
    </div>
  `;
  document.getElementById("quiz").style.display = "block";
  carregarPergunta();
}

function carregarPergunta() {
  const perguntaAtual = perguntas[indice];
  
  document.getElementById("pergunta").innerHTML = `
    <p class="pergunta-texto">${perguntaAtual.pergunta}</p>
  `;

  document.getElementById("equipeAtualLabel").textContent = `Equipe ${equipeAtual}`;
  const opcoesDiv = document.getElementById("opcoes");
  const btnProximo = document.getElementById("btnProximo");

  opcoesDiv.innerHTML = "";
  btnProximo.style.display = "none";

  perguntaAtual.opcoes.forEach(opcao => {
    const botao = document.createElement("button");
    botao.textContent = opcao.texto;
    botao.onclick = () => selecionarResposta(botao, opcao.pontos);
    opcoesDiv.appendChild(botao);
  });

  atualizarPlacar();
}

function selecionarResposta(botao, pontos) {
  const botoes = document.querySelectorAll("#opcoes button");

  botoes.forEach(btn => {
    btn.disabled = true;
    btn.classList.remove("correta"); // Remove a classe verde de todos
  });

  // Aplica verde apenas no botão selecionado
  botao.classList.add("correta");
  
  pontuacao[equipeAtual] += pontos;
  document.getElementById("somAcerto").play();
  document.getElementById("btnProximo").style.display = "block";
}

function proximaPergunta() {
  indice++;
  equipeAtual = equipeAtual === "A" ? "B" : "A";

  if (indice < perguntas.length) {
    carregarPergunta();
  } else {
    const vencedor =
      pontuacao.A > pontuacao.B
        ? "🎉 Equipe A venceu!"
        : pontuacao.B > pontuacao.A
          ? "🎉 Equipe B venceu!"
          : "🤝 Empate!";

    document.getElementById("somVitoria").play();

    document.getElementById("quiz").innerHTML = `
      <div class="resultado-final">
        <p>Placar final:</p>
        <p>Equipe A: ${pontuacao.A} ponto(s)</p>
        <p>Equipe B: ${pontuacao.B} ponto(s)</p>
        <strong>${vencedor}</strong>
        <button class="botao-reiniciar" onclick="iniciarQuiz('A')">🔄 Jogar Novamente</button>
      </div>
    `;
  }
}

function atualizarPlacar() {
  document.getElementById("placar").innerHTML = `
    <span class="azul"> ⚫ Equipe A: ${pontuacao.A}</span>
    <span class="preta">⚫ Equipe B: ${pontuacao.B}</span>
  `;
}