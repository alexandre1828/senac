const perguntas = [
  // Perguntas originais
  {
    pergunta: "Você vê um novo aplicativo bombando, todo mundo comentando e testando. As conversas com seus amigos giram em torno disso, e você se pergunta se deveria entrar nessa também. Bate aquele desejo de não ficar de fora, mas, ao mesmo tempo, vem a ideia de não participar de algo só porque está sendo muito comentado — afinal, daqui a pouco essa onda passa e outro aplicativo surge",
    opcoes: [
      { texto: "Entrar", pontos: 10 },
      { texto: "Ficar de fora", pontos: 10 }
    ]
  },
  {
    pergunta: "Você vê uma postagem de alguém próximo. A legenda possui uma opinião divergente dos seus princípios. Seus dedos coçam para responder o que pensa. Só o que você teme sobre o que essa discordância pode fazer com a relação de vocês.",
    opcoes: [
      { texto: "Se posicionar", pontos: 10 },
      { texto: "Ficar em silêncio", pontos: 10 }
    ]
  },
  {
    pergunta: "Você olha seu perfil como um quarto bagunçado. Com 2 mil seguidores, mas a conta já não parece mais sua. São fases misturadas, versões antigas que continuam lá, em postagens e stories salvos. Tudo parecia pensado demais, polido demais, sempre esperando reações — e isso começa a te incomodar.",
    opcoes: [
      { texto: "Permanecer", pontos: 20 },
      { texto: "Recomeçar", pontos: 10 }
    ]
  },
  {
    pergunta: "Você olha o perfil da pessoa que te faz sentir borboletas no estômago. Segue, mas nunca interage. Teme ser notado(a), mas também teme continuar invisível. A pessoa que você gosta está ali, a poucos cliques de distância, mas não consegue dar o primeiro passo. Ensaia um comentário, um 'nossa, isso é muito você'. Mas trava. Apaga. Volta ao silêncio. O medo de parecer carente ou fora de lugar te paralisa. Você repensa receoso(a).",
    opcoes: [
      { texto: "Interagir", pontos: 10 },
      { texto: "Ficar em silêncio", pontos: 20 }
    ]
  },
  {
    pergunta: "Você está a uma hora estudando, cheio de tarefas para fazer, mas se sente estressado, não consegue focar, mas acaba de receber uma notificação em uma rede social de um amigo.",
    opcoes: [
      { texto: "Continuar estudando", pontos: 20 },
      { texto: "Visualizar", pontos: 10 }
    ]
  },
  {
    pergunta: "Você tira uma foto que gosta. Talvez não seja perfeita, mas tem algo interessante que te faz querer publicar. Pensa em postar. Mas então vem a dúvida: e se ninguém curtir? E se comentarem algo ruim? Seu dedo hesita sobre o botão de postar.",
    opcoes: [
      { texto: "Postar mesmo assim", pontos: 20 },
      { texto: "Guardar a foto", pontos: 10 }
    ]
  },
  {
    pergunta: "Você está em um jantar especial, com uma paisagem de tirar o fôlego. Mas antes de aproveitar você pensa em sacar o celular para registrar o momento, mostrar que está ali.",
    opcoes: [
      { texto: "Viver o momento", pontos: 20 },
      { texto: "Registrar tudo", pontos: 10 }
    ]
  },

  // Novas perguntas adicionadas
  {
    pergunta: "Trend nova no TikTok ou postar aquele story bonito no Instagram?",
    opcoes: [
      { texto: "Participar da trend", pontos: 15 },
      { texto: "Postar o story", pontos: 15 },
      { texto: "Ficar só olhando tudo", pontos: 10 }
    ]
  },
  {
    pergunta: "Postar a selfie do churras com a turma ou a foto do jantar em família?",
    opcoes: [
      { texto: "Postar o churras", pontos: 15 },
      { texto: "Postar a família", pontos: 15 },
      { texto: "Guardar só pra mim", pontos: 10 }
    ]
  },
  {
    pergunta: "Comprar a roupa igual a dos influencers ou usar o look que você já tem e fazer sua própria festa?",
    opcoes: [
      { texto: "Comprar o look da moda", pontos: 10 },
      { texto: "Usar o que já tem", pontos: 20 },
      { texto: "Nem ir mais", pontos: 5 }
    ]
  },
  {
    pergunta: "Recebe DM de um influencer com 40 mil seguidores, mas o crush também mandou mensagem.",
    opcoes: [
      { texto: "Responder o influencer", pontos: 10 },
      { texto: "Responder o crush", pontos: 20 },
      { texto: "Deixar os dois no vácuo", pontos: 5 }
    ]
  },
  {
    pergunta: "Sua amiga te chama pra sair e tirar fotos num lugar top, mas você tinha planejado descansar.",
    opcoes: [
      { texto: "Sair com a amiga e fazer conteúdo", pontos: 15 },
      { texto: "Ficar em casa no descanso", pontos: 15 },
      { texto: "Sair, mas não postar nada", pontos: 10 }
    ]
  },
  {
    pergunta: "Apaga todas as fotos antigas do Instagram ou deixa como estão mesmo?",
    opcoes: [
      { texto: "Apaga tudo e recomeça", pontos: 10 },
      { texto: "Deixa tudo lá", pontos: 15 },
      { texto: "Só arquiva as vergonhosas", pontos: 20 }
    ]
  },
  {
    pergunta: "Te marcaram numa foto feia...",
    opcoes: [
      { texto: "Desmarca rápido", pontos: 10 },
      { texto: "Comenta fazendo piada", pontos: 20 },
      { texto: "Ignora e segue o baile", pontos: 15 }
    ]
  },
  {
    pergunta: "Postar a viagem perfeita ou guardar o momento só pra você?",
    opcoes: [
      { texto: "Postar tudo", pontos: 10 },
      { texto: "Postar só algumas", pontos: 15 },
      { texto: "Não postar nada", pontos: 20 }
    ]
  },
  {
    pergunta: "Um perfil fake começa a te zoar nos comentários.",
    opcoes: [
      { texto: "Denuncia", pontos: 20 },
      { texto: "Ignora", pontos: 15 },
      { texto: "Responde publicamente", pontos: 10 }
    ]
  },
  {
    pergunta: "Recebeu um convite pra entrar em um grupo VIP de seguidores.",
    opcoes: [
      { texto: "Entra e participa", pontos: 10 },
      { texto: "Só entra pra olhar", pontos: 15 },
      { texto: "Nem entra", pontos: 20 }
    ]
  },
  {
    pergunta: "Seu amigo começou a bombar nas redes e tá diferente com você.",
    opcoes: [
      { texto: "Chama pra conversar", pontos: 20 },
      { texto: "Para de seguir", pontos: 10 },
      { texto: "Finge que nada mudou", pontos: 15 }
    ]
  },
  {
    pergunta: "Você tem que escolher entre fazer um trabalho em grupo ou um Reels que pode viralizar.",
    opcoes: [
      { texto: "Faz o trabalho", pontos: 20 },
      { texto: "Grava o Reels", pontos: 10 },
      { texto: "Tenta fazer os dois", pontos: 15 }
    ]
  },
  {
    pergunta: "Influencer favorito posta uma indireta que parece pra você.",
    opcoes: [
      { texto: "Responde nos stories", pontos: 10 },
      { texto: "Ignora", pontos: 20 },
      { texto: "Para de seguir", pontos: 15 }
    ]
  },
  {
    pergunta: "Você tem 3 eventos no mesmo dia: um top pra fotos, um de família e um pra descansar.",
    opcoes: [
      { texto: "Vai no top pra postar", pontos: 10 },
      { texto: "Vai na família", pontos: 20 },
      { texto: "Fica em casa", pontos: 15 }
    ]
  },
  {
    pergunta: "Estão espalhando que você editou demais uma foto.",
    opcoes: [
      { texto: "Assume a edição", pontos: 20 },
      { texto: "Diz que é inveja", pontos: 10 },
      { texto: "Some das redes um tempo", pontos: 15 }
    ]
  },
  {
    pergunta: "Você perde seguidores depois de postar algo sincero.",
    opcoes: [
      { texto: "Apaga o post", pontos: 10 },
      { texto: "Deixa lá", pontos: 20 },
      { texto: "Faz outro desabafando mais ainda", pontos: 15 }
    ]
  },
  {
    pergunta: "Alguém copiou seu estilo de post e tá ganhando mais visibilidade.",
    opcoes: [
      { texto: "Finge que não viu", pontos: 15 },
      { texto: "Muda seu estilo", pontos: 10 },
      { texto: "Fala nos stories", pontos: 20 }
    ]
  },
  {
    pergunta: "Você está com 1% de bateria, responde o crush ou grava o story?",
    opcoes: [
      { texto: "Responde o crush", pontos: 20 },
      { texto: "Grava o story", pontos: 10 },
      { texto: "Salva a bateria", pontos: 15 }
    ]
  },
  {
    pergunta: "Te oferecem publi de um produto duvidoso.",
    opcoes: [
      { texto: "Aceita pelo dinheiro", pontos: 10 },
      { texto: "Recusa", pontos: 20 },
      { texto: "Pergunta pro público o que acham", pontos: 15 }
    ]
  },
  {
    pergunta: "Post antigo seu começa a viralizar e virar meme.",
    opcoes: [
      { texto: "Aproveita a fama", pontos: 20 },
      { texto: "Tira do ar", pontos: 10 },
      { texto: "Faz piada com você mesmo", pontos: 15 }
    ]
  }
];

// Restante do código permanece igual
let indice = 0;
let equipeAtual = "A";
let pontuacao = { A: 0, B: 0 };

function iniciarQuiz(equipe) {
  equipeAtual = equipe;
  indice = 0;
  pontuacao = { A: 0, B: 0 };
  document.getElementById("quiz").innerHTML = `
    <div class="post-header">
      <img src="imagens/icon.jpg" alt="perfil" class="post-img">
      <span class="post-user" id="equipeAtualLabel">Equipe ${equipeAtual}</span>
    </div>
    <div class="post-body">
      <p id="pergunta"></p>
      <div id="opcoes" class="opcoes"></div>
      <button id="btnProximo" onclick="proximaPergunta()">Próxima</button>
      <div class="placar" id="placar"></div>
    </div>
  `;
  document.getElementById("quiz").style.display = "block";
  carregarPergunta();
}

function carregarPergunta() {
  const perguntaAtual = perguntas[indice];
  
  document.getElementById("pergunta").innerHTML = `
    <p class="pergunta-texto">${perguntaAtual.pergunta}</p>
  `;

  document.getElementById("equipeAtualLabel").textContent = `Equipe ${equipeAtual}`;
  const opcoesDiv = document.getElementById("opcoes");
  const btnProximo = document.getElementById("btnProximo");

  opcoesDiv.innerHTML = "";
  btnProximo.style.display = "none";

  perguntaAtual.opcoes.forEach(opcao => {
    const botao = document.createElement("button");
    botao.textContent = opcao.texto;
    botao.onclick = () => selecionarResposta(botao, opcao.pontos);
    opcoesDiv.appendChild(botao);
  });

  atualizarPlacar();
}

function selecionarResposta(botao, pontos) {
  const botoes = document.querySelectorAll("#opcoes button");

  botoes.forEach(btn => {
    btn.disabled = true;
    btn.classList.remove("correta");
  });

  botao.classList.add("correta");
  
  pontuacao[equipeAtual] += pontos;
  document.getElementById("somAcerto").play();
  document.getElementById("btnProximo").style.display = "block";
}

function proximaPergunta() {
  indice++;
  equipeAtual = equipeAtual === "A" ? "B" : "A";

  if (indice < perguntas.length) {
    carregarPergunta();
  } else {
    const vencedor =
      pontuacao.A > pontuacao.B
        ? "🎉 Equipe A venceu!"
        : pontuacao.B > pontuacao.A
          ? "🎉 Equipe B venceu!"
          : "🤝 Empate!";

    document.getElementById("somVitoria").play();

    document.getElementById("quiz").innerHTML = `
      <div class="resultado-final">
        <p>Placar final:</p>
        <p>Equipe A: ${pontuacao.A} ponto(s)</p>
        <p>Equipe B: ${pontuacao.B} ponto(s)</p>
        <strong>${vencedor}</strong>
        <button class="botao-reiniciar" onclick="iniciarQuiz('A')">🔄 Jogar Novamente</button>
      </div>
    `;
  }
}

function atualizarPlacar() {
  document.getElementById("placar").innerHTML = `
    <span class="azul"> ⚫ Equipe A: ${pontuacao.A}</span>
    <span class="preta">⚫ Equipe B: ${pontuacao.B}</span>
  `;
}